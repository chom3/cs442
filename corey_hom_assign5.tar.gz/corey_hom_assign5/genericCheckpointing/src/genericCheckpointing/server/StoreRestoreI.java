package genericCheckpointing.server;

public interface StoreRestoreI {
    
}