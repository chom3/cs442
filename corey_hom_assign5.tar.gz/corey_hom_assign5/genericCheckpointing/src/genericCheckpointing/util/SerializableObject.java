package genericCheckpointing.util;


//Empty base class?
public class SerializableObject{
    
}